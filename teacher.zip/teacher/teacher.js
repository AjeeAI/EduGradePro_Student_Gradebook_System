console.log("✅ teacher.js loaded");

let reportBtn = document.getElementById('report-btn');
let homeBtn = document.getElementById('homeBtn');
let settingsBtn = document.getElementById('settings');   
if (reportBtn) {
    reportBtn.addEventListener('click', () => {
        console.log("Navigating to Reports...");
        window.location.href = '/teacher/reports.html';
    });
}

if (homeBtn) {
    homeBtn.addEventListener('click', () => {
        console.log("Returning to Dashboard...");
        window.location.href = '/teacher/dashboard.html';
    });
}

if (settingsBtn) {
    settingsBtn.addEventListener('click', () => {
        console.log("Settings clicked");
        window.location.href="/teacher/settings.html";
        // Future implementation for settings
    });
}
